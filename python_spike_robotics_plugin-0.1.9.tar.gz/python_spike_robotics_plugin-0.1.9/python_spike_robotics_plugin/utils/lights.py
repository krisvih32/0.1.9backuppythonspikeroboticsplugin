import light_matrix # imports dummy directory
# START_OF_FILE lights.py
# TODO: DO NOT REMOVE THE START and END of FILE MARKERS
async def write(message: str):
	message=str(message)
	await light_matrix.write(message)
# END_OF_FILE lights.py