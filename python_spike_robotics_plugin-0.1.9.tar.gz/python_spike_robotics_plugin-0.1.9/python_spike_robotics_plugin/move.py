from math import pi
from hub import port
from motor_pair import pair, move_for_degrees, PAIR_1, PAIR_2, PAIR_3
from auto_enum import Enum
class Longitudinal:
    def __init__(self, direction: str) -> None:
        if direction in ["Forward", "Backward"]:
            self.direction = direction
        else:
            raise ValueError("Direction not Forward or Backward")
    def __str__(self):
        return self.direction
    
class MotorPair:
    def __init__(self, motor1: port, motor2: port, motor_pair: PAIR_1|PAIR_2|PAIR_3, wheel_diameters_in_cm: float) -> None:
        self.motor1 = motor1
        self.motor2 = motor2
        self.diameter_in_cm = wheel_diameters_in_cm
        self.motor_pair = pair(motor_pair, self.motor1, self.motor2)

    def move_rotations(self, rotations: float, direction: Longitudinal) -> None :
        self.motor_pair.move_for_degrees(self.motor_pair, rotations*360 if direction == "Forward" else -rotations*360, 0)

    def move_forward_cm(self, cm: float, direction: Longitudinal) -> None:
        rotations = self.__calculate_rotations(self.diameter_in_cm, cm, self.motor1, self.motor2)
        self.move_rotations(rotations, direction)

    def __calculate_rotations(self, distance_in_cm: float) -> None:
        # Calculate the circumference of the wheel
        circumference = pi * self.diameter_in_cm
        # Calculate the number of rotations
        rotations = distance_in_cm / circumference
        return rotations

