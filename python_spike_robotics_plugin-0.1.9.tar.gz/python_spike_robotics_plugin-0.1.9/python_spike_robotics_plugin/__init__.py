# your_package/__init__.py

from shutil import move
from os import makedirs, path
exists=path.exists
del path
from command_runner.elevate import elevate

# Define the source and destination paths
SOURCE_DIR = "cruft"  # Path to the source directory
IMPORTS_FILE = "cruft/imports.py"  # Path to the imports.py file
DESTINATION_DIR = "/python_spike_robotics_plugin/"  # Destination directory

# Define a marker file to track if the files have been moved
MARKER_FILE = os.path.join(os.path.dirname(__file__), "files_moved.marker")  # Store marker in the package directory
def __move_files__():
    makedirs(DESTINATION_DIR, exist_ok=True)
    move(SOURCE_DIR, DESTINATION_DIR)
    move(IMPORTS_FILE, os.path.join(DESTINATION_DIR, "imports.py"))
    with open(MARKER_FILE, 'w') as f:
        f.write("Marker file to indicate files have been moved.")
def move_files():
    # Check if the marker file exists
    if not exists(MARKER_FILE):
        try:
            __move_files__()
        except PermissionError:
            elevate(__move_files__)
        except FileNotFoundError as e:
            print(f"Error: {e.strerror}: {e.filename}")  # Print the error message for missing files
        except Exception as e:
            print(f"Error moving files: {e}")  # Print the error message

# Call the function to move the files when the package is imported
move_files()