def run_command():
    print("Hello! This is your post-install command running!")
