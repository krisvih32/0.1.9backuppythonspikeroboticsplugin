# A python spike robotics plugin
## OS Compatibility
- Windows
- Linux
- Macos
- FreeBSD
- OpenBSD
## Installation
pip install -i https://test.pypi.org/simple/ python-spike-robotics-plugin